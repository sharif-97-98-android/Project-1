package com.example.myapplication;

import java.util.ArrayList;

public class ConnectionManager{

    int[] message = new int[10];
    int time = 0;
    public ConnectionManager(int time){
        this.time = time;
    }
    public void load(int firstMessage) throws InterruptedException {
            Thread.sleep(time);
            for (int i = 0; i < 10; ++i) {
                this.message[i] = firstMessage + i + 1;
            }
    }
}
