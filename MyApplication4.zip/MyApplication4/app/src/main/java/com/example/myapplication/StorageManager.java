package com.example.myapplication;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class StorageManager{
    private int lastmessage = 0;
    int[] message = new int[10];
    //FileOutputStream fOut = null;
    //FileInputStream fIn = null;
    //MainActivity x = new MainActivity();
    public StorageManager() throws IOException {

        //File file = new File(x.getFilesDir(), "store");
        //fOut = new FileOutputStream(file);
        //fIn = new FileInputStream(file);
        //this.lastmessage = fIn.read();
        //System.out.println(this.lastmessage);
    }
    public void load(int firstmessage) throws IOException {
        //this.lastmessage = fIn.read();
        if(firstmessage < lastmessage) {
            for (int i = firstmessage; i < firstmessage + 10; ++i) {
                message[i - firstmessage] = i + 1;
            }
        }
    }
    public void save(int lastmessage) throws IOException {
        //this.lastmessage = fIn.read();
        if(this.lastmessage < lastmessage) {
            this.lastmessage = lastmessage;
            //fOut.flush();
            //fOut.write(this.lastmessage);
        }

    }
}
