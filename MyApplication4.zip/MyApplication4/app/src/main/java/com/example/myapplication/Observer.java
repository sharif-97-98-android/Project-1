package com.example.myapplication;

public interface Observer {
    public void update(final boolean checked);
}
